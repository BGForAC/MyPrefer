package gql.myProject.controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "template", urlPatterns = "/template")
public class template extends HttpServlet {

    protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 设置请求的的字符编码
        request.setCharacterEncoding("UTF-8");

        // 创建JSON对象来存储响应数据
        String json = "";


        // 设置响应内容类型
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // 通过PrintWriter返回给客户端
        response.getWriter().println(json);
        response.getWriter().flush();

        response.setContentType("text/html");
    }
}